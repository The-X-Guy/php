<?php
    session_start();
    session_name("registro");
    echo "
        <h3>Formulario de registro.</h3>
        <form method='post' action='".$_SERVER['PHP_SELF']."'>
            <div>
                <label>Nombre: </label>
                <input name='nombre' type='text'>
            </div>
            <div>
                <label>Apellidos: </label>
                <input name='apellidos' type='text'>
            </div>
            <div>
                <label>Email: </label>
                <input name='email' type='email'>
            </div>
            <div>
                <input type='submit' value='Registrar'>
            </div>
        </form>
    ";

    if($_POST){
        $_SESSION['nombre'] = $_POST['nombre'];
        $_SESSION['apellidos'] = $_POST['apellidos'];
        $_SESSION['email'] = $_POST['email'];

        echo "Redirigiendo a la página de compra en 5 segundos...";
        header("Refresh: 5; URL=./compras.php");
        exit();
    }
?>