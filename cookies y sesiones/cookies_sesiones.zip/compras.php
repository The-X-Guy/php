<?php
    session_start();
    echo "
        <h3>Sus datos son:</h3>
        <ul>
            <li>Nombre: ".$_SESSION['nombre']."</li>
            <li>Apellidos: ".$_SESSION['apellidos']."</li>
            <li>Email: ".$_SESSION['email']."</li>
        </ul>
        <h3>Precios:</h3>
        <ul>
            <li>Motos: 2.000€</li>
            <li>Coches: 10.000€</li>
            <li>Patinetes: 300€</li>
        </ul>
        <h3>Selecciona qué quieres comprar y la cantidad:</h3>
        <form action='./validacion.php' method='post'>
            <div>
                <label><input type='checkbox' name='motos'>Motos: </label>
                <input type='number' name='motos_num'>
            </div>
            <div>
                <label><input type='checkbox' name='coches'>Coches: </label>
                <input type='number' name='coches_num'>
            </div>
            <div>
                <label><input type='checkbox' name='patinetes'>Patinetes: </label>
                <input type='number' name='patinetes_num'>
            </div>
            <input type='submit' name='enviar' value='calcular'>
        </form>
    ";

    
?>