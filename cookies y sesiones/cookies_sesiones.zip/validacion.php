<?php
session_start();
 echo "
 <h3>Sus datos son:</h3>
 <ul>
     <li>Nombre: ".$_SESSION['nombre']."</li>
     <li>Apellidos: ".$_SESSION['apellidos']."</li>
     <li>Email: ".$_SESSION['email']."</li>
 </ul>
";
error_reporting(0);
if ($_POST) {
    if ($_POST['motos']) $motos = $_POST['motos_num'];
    if ($_POST['coches']) $coches = $_POST['coches_num'];
    if ($_POST['patinetes']) $patinetes = $_POST['patinetes_num'];

    $precios = array(2000, 10000, 300);
    $motos_total = 0;
    $coches_total = 0;
    $patinetes_total = 0;

    $url = "./confirmacion.php?";

    $datos = array(
        "Motos" => array(),
        "Coches" => array(),
        "Patinetes" => array()
    );

    if (isset($_POST['motos'])) {
        $motos_total = $motos*$precios[0];
        array_push($datos['Motos'], $motos, $motos_total);
        // $url .= "item=Motos&motos_cant=".$datos["Motos"][0]."&motos_precio=".$datos["Motos"][1];
    }
    if (isset($_POST['coches'])) {
        $coches_total = $coches*$precios[1];
        array_push($datos['Coches'], $coches, $coches_total);
        // $url .= "&item=Coches&coches_cant=".$datos["Coches"][0]."&coches_precio=".$datos["Coches"][1];
    }
    if (isset($_POST['patinetes'])) {
        $patinetes_total = $patinetes*$precios[2];
        array_push($datos['Patinetes'], $patinetes, $patinetes_total);
        // $url += "&item=Patinetes&patinetes_cant=".$datos["Patinetes"][0]."&patinetes_precio=".$datos["Patinetes"][1];
    }
    
    $total = $motos_total + $coches_total + $patinetes_total;

    $datos_keys = array_keys($datos);
    $i = 0;
    echo "<h3>Confirmación de la compra.</h3>";
    echo "<ul>";
    foreach($datos as $valor) {
        echo "<li>Artículo: ".$datos_keys[$i].", cantidad: ".$valor[0].", precio: ".$valor[1]."</li>";
        $i++;
    }
    echo "<li>Total compra: ".$total."</li>";
    echo "</ul>";

    session_destroy();
    
    // $url .= "&total=".$total;
    // echo $url;
    // header("Refresh: 0; URL=$url");
    // exit();
}
?>