<?php
    error_reporting(0);
    function conexion() {
        require_once('connection_data.php');
        $mysqli = new mysqli($hostname, $username, $password);

        if ($mysqli->connect_errno) {
            die("Error conectando al gestor de bases de datos: ".$mysqli->connect_errno."<br>");
        } else {
            echo "Conexión correcta al gestor de bases de datos.<br>";
        }
        return $mysqli;
    }
    

    $sentencias = array (
        "create database if not exists vehiculos",
        "use vehiculos",
        "create table color (
            codcolor int(6) primary key,
            tipocolor char(10)
        );",
        "create table if not exists marcas (
            codmarca int(6) primary key,
            nommarca char(15)
        );",
        "create table if not exists piezas (
            codpie int(6) primary key,
            nombrepie char(15) not null,
            unidades int(6)
        );",
        "create table if not exists taller (
            codtall int(6) primary key,
            nombretall char(15) not null,
            direcctal char(20)
        );",
        "create table if not exists vehiculo (
            codvehi int(6) primary key,
            nomveh char(15) not null,
            codmarca int(6) references marcas,
            codcolor int(6) references color,
            unidades int(7),
            precio int(7)
        );",
        "create table if not exists clientes (
            codcli int(7) primary key,
            nombre char(15) not null,
            apellidos char(25) not null,
            direccion char(20),
            cp int(5)
        );",
        "create table if not exists aprendiz (
            codapre int(7) primary key,
            nombre char(15) not null,
            apellidos char(25) not null,
            direccion char(20),
            cp int(5)
        );",
        "create table if not exists alquiler (
            numalq int(7) primary key,
            codvehi int(7) references coches,
            codcli int(7) references clientes,
            fecha date,
            cantidad int(7)
        );",
        "create table if not exists lineapiezas (
            codlinepie int(6) primary key,
            codtall int(6) references taller on delete cascade on update cascade,
            codpie int(6) references pieza on delete cascade on update cascade,
            cantpedido int(7),
            fecha date
        );"
    );

    echo "
        <form action=".$_SERVER['PHP_SELF']." method='post'>
            <div>
                <h3>0. Crear base de datos.</h3>
                <input type='submit' name='create' value='Crear'>
            </div>
            <div>
                <h3>1. Sacar todos los nombres de marcas de vehículos, así como los nombres de dichos vehículos de aquellos que fueron alquilados por clientes cuyo apellido comienza por S, termina por Z o tiene  tres A intercaladas, y alquilaron en el año 2004 ,su código  postal es el 29620, 29621, 29622, o 29623 y alquilaron algún vehículo de color rojo.</h3>
                <input type='submit' name='ej1' value='Ejecutar'>
            </div>
            <div>
                <h3>2. Modificar  el precio de todos los vehículos  cuya marca sea SEAT, alquilados por aquellos clientes que tengan la misma dirección que el cliente Antonio Pérez o el mismo código postal que el aprendiz Luis García y alquilaron más de 7 SEAT</h3>
                <input type='submit' name='ej2' value='Ejecutar'>
            </div>
            <div>
                <h3>3. Sacar el tipocolor, nombre de la marca de aquellos vehículos alquilados por los clientes que tengan el  mismo código postal que Luis Fernández o Antonio gómez</h3>
                <input type='submit' name='ej3' value='Ejecutar'>
            </div>
            <div>
                <h3>4. Sacar los nombre de vehículos, el número de veces alquilado por vehículo y las cantidades acumuladas en los alquileres de aquellos cuya cantidad acumulada supere los 1000 € ordenados alfabéticamente por nombre de vehículo.</h3>
                <input type='submit' name='ej4' value='Ejecutar'>
            </div>
            <div>
                <h3>5. Modificar el color del vehículo a rojo de aquellos que sean de marca SEAT y lo alquilasen clientes con la misma dirección que el aprendiz Antonio León y el código postal que los clientes que se apellidan Suárez, Vera, Guzmán o Tribujano.</h3>
                <input type='submit' name='ej5' value='Ejecutar'>
            </div>
            <div>
                <h3>6. Sacar el nombre y apellidos de aquellos aprendices cuyo apellido comienza por la letra A y su dirección coincide con la del aprendiz José Pérez</h3>
                <input type='submit' name='ej6' value='Ejecutar'>
            </div>
            <div>
                <h3>7. Borrar todas las marcas cuyo nombre tenga 2 letras E en el interior, y tengan algún vehículo de color rojo o verde cuyo acumulado de alquileres supere los 3400 €.</h3>
                <input type='submit' name='ej7' value='Ejecutar'>
            </div>
            <div>
                <h3>8. Sacar nombre vehículo, suma acumulada de las cantidades de los alquileres, tipocolor y nombre del cliente cuya marca sea SEAT o CITROEN, el color de los vehículos amarillo, el código del  vehículo este en el rango 1000 y 2000 y dichas cantidades superen los 500 €</h3>
                <input type='submit' name='ej8' value='Ejecutar'>
            </div>
            <div>
                <h3>9. Borrar el taller 2 y 9.</h3>
                <input type='submit' name='ej9' value='Ejecutar'>
            </div>
            <div>
                <h3>10. Borrar todas las tablas.</h3>
                <input type='submit' name='ej10' value='Ejecutar'>
            </div>
        </form>
    ";

    if ($_POST) {
        if ($_POST['create']) {
            $mysqli = conexion();
            foreach ($sentencias as $sentencia) {
                printf("<br><strong>Ejecutando sentencia: </strong>"."<br>".$sentencia."<br>");
                $mysqli->query($sentencia);
            }
            $mysqli->close();
        }
        if ($_POST['ej1']) {
            $mysqli = conexion();
            $query =  "
                select marcas.nommarca, vehiculo.nomveh 
                from marcas inner join vehiculo using(codmarca)
                            inner join alquiler using(codvehi)
                            inner join clientes using(codcli)
                            cross join color on color.codcolor = vehiculo.codcolor
                where apellidos like 'S%' or apellidos like '%z' or apellidos like '%a%a%a%'
                      and alquiler.fecha = 2004 and clientes.cp in(29620, 29621, 29622, 29623)
                      and tipocolor = 'rojo'
            ";
            $res = $mysqli->query($query);
            if ($res == null) {
                die("No hay resultados.");
            }
            while ($rows = $res->fetch_assoc()) {
                print("<tr>");
                print("<td>".$rows["nommarca"]."</td>");
                print("<td>".$rows["nomveh"]."</td>");
                print("</tr>");
            }
            print("</table>");
            echo $res->num_rows." registros procesados";
            $res->free();
            $mysqli->close();
        }
        if ($_POST['ej2']) {
            $mysqli = conexion();
            $query = "
                update vehiculo inner join marcas using(codmarca), 
                       clientes inner join alquiler using(codcli) 
                set precio = 5000 
                where nommarca = 'SEAT' and 
                      alquiler.codcli = (select codcli 
                                         from clientes 
                                         where direccion = (select direccion 
                                                            from clientes 
                                                            where nombre = 'Antonio' and apellidos = 'Perez'))
                      and cp = (select cp 
                                from clientes 
                                where nombre = 'Luis' and apellidos = 'Garcia')
                      and alquiler.cantidad > 7
            ";
            $res = $mysqli->query($query);
            if ($res == null) {
                die("No hay resultados.");
            }
            echo $res->num_rows." registros procesados";
            $res->free();
            $mysqli->close();
        }
        if ($_POST['ej3']) {
            $mysqli = conexion();
            $query = "
                select tipocolor, nommarca
                from COLOR inner join VEHICULO on COLOR.codcolor = VEHICULO.codcolor
                        inner join MARCA on VEHICULO.codmarca = MARCA.codmarca
                        inner join ALQUILER on ALQUILER.codvehi = VEHICULO.codvehi
                        inner join CLIENTES on ALQUILER.codcli = CLIENTES.codcli
                where CLIENTES.cp in (select cp
                                    from CLIENTES
                                    where nombre='Luis' and apellidos='Fernández'
                                    or nombre='Antonio' and apellidos='Gómez')
            ";
            $res = $mysqli->query($query);
            if ($res == null) {
                die("No hay resultados.");
            }
            while ($rows = $res->fetch_assoc()) {
                print("<tr>");
                print("<td>".$rows["fecha"]."</td>");
                print("<td>".$rows["tipocolor"]."</td>");
                print("</tr>");
            }
            print("</table>");
            echo $res->num_rows." registros procesados";
            $res->free();
            $mysqli->close();
        }
        if ($_POST['ej4']) {
            $mysqli = conexion();
            $query = "
                select nomveh, count(numalq), sum(cantidad)
                from VEHICULO inner join ALQUILER on VEHICULO.codvehi = ALQUILER.codvehi
                group by nomveh
                having sum(cantidad) > 1000
                order by nomveh asc
            ";
            $res = $mysqli->query($query);
            if ($res == null) {
                die("No hay resultados.");
            }
            while ($rows = $res->fetch_assoc()) {
                print("<tr>");
                print("<td>".$rows["nomveh"]."</td>");
                print("<td>".$rows["count(numalq)"]."</td>");
                print("<td>".$rows["sum(cantidad)"]."</td>");
                print("</tr>");
            }
            print("</table>");
            echo $res->num_rows." registros procesados";
            $res->free();
            $mysqli->close();
        }
        if ($_POST['ej5']) {
            $mysqli = conexion();
            $query = "
                update COLOR
                set tipocolor='rojo'
                where nommarca='SEAT'
                    and codcli in (select codcli
                                from CLIENTES
                                            where direccion = (select direccion
                                                            from CLIENTES
                                                            where nombre='Antonio' and apellidos='Leon')
                                            and cp = (select cp 
                                                    from CLIENTES
                                                    where apellidos in ('Suarez','Vera','Guzman','Tribujano')))
            ";
            $res = $mysqli->query($query);
            if ($res == null) {
                die("No hay resultados.");
            }
            echo $res->num_rows." registros procesados";
            $res->free();
            $mysqli->close();
        }
        if ($_POST['ej6']) {
            $mysqli = conexion();
            $query = "
                select nombre, apellidos
                from APRENDIZ
                where apellidos like 'A*'
                    and direccion = (select direccion
                                    from APRENDIZ
                                    where nombre='Jose' and apellidos='Perez')
            ";
            $res = $mysqli->query($query);
            if ($res == null) {
                die("No hay resultados.");
            }
            while ($rows = $res->fetch_assoc()) {
                print("<tr>");
                print("<td>".$rows["nombre"]."</td>");
                print("<td>".$rows["apellidos"]."</td>");
                print("</tr>");
            }
            print("</table>");
            echo $res->num_rows." registros procesados";
            $res->free();
            $mysqli->close();
        }
        if ($_POST['ej7']) {
            $mysqli = conexion();
            $query = "
                delete 
                from marca inner join vehiculo using(codmarca)
                           inner join alquiler using(codvehi)
                where nommarca like '*e*e*'
                      and color.codcolor = (select codcolor
                                            from COLOR
                                            where tipocolor in('rojo','verde'))
                      and sum(alquiler.cantidad) > 3400
            ";
            $res = $mysqli->query($query);
            if ($res == null) {
                die("No hay resultados.");
            }
            echo $res->num_rows." registros procesados";
            $res->free();
            $mysqli->close();
        }
        if ($_POST['ej8']) {
            $mysqli = conexion();
            $query = "
                select nomveh, sum(cantidad), tipocolor, CLIENTES.nombre
                from MARCA inner join VEHICULO on MARCA.codmarca = VEHICULO.codmarca
                           inner join ALQUILER on ALQUILER.codvehi = VEHICULO.codvehi
                           inner join CLIENTES on CLIENTES.codcli = ALQUILER.codcli
                           cross join COLOR on COLOR.codcolor = VEHICULO.codcolor
                where nommarca in('SEAT','CITROEN')
                    and VEHICULO.codcolor = (select codcolor
                                             from COLOR
                                             where tipocolor='amarillo')
                    and VEHICULO.codvehi between 1000 and 2000
                    group by nomveh
                    having sum(cantidad)>500
            ";
            $res = $mysqli->query($query);
            if ($res == null) {
                die("No hay resultados.");
            }
            while ($rows = $res->fetch_assoc()) {
                print("<tr>");
                print("<td>".$rows["nomveh"]."</td>");
                print("<td>".$rows["sum(cantidad)"]."</td>");
                print("<td>".$rows["tipocolor"]."</td>");
                print("<td>".$rows["clientes.nombre"]."</td>");
                print("</tr>");
            }
            print("</table>");
            echo $res->num_rows." registros procesados";
            $res->free();
            $mysqli->close();
        }
        if ($_POST['ej9']) {
            $mysqli = conexion();
            $query = "delete from taller where codtall in (2, 9)";
            $res = $mysqli->query($query);
            if ($res == null) {
                die("No hay resultados.");
            }
            echo $res->num_rows." registros procesados";
            $res->free();
            $mysqli->close();
        }
        if ($_POST['ej10']) {
            $mysqli = conexion();
            $query = array(
                "drop table if exists taller",
                "drop table if exists vehiculo",
                "drop table if exists aprendiz",
                "drop table if exists clientes",
                "drop table if exists color",
                "drop table if exists piezas",
                "drop table if exists lineapieza",
                "drop table if exists marcas",
                "drop table if exists alquiler"
            );
            foreach ($query as $sentencia) {
                printf("<br><strong>Borrando: </strong>"."<br>".$sentencia."<br>");
                $mysqli->query($sentencia);
            }
            $res->free();
            $mysqli->close();
        }
    }
?>