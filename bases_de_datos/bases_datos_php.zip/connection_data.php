<?php
    $hostname = 'localhost';
    $username = 'root';
    $password = '';
?>